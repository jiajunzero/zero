/*
Navicat MySQL Data Transfer

Source Server         : wamp
Source Server Version : 50711
Source Host           : 127.0.0.1:3306
Source Database       : loca.itshop.com

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-09-27 20:52:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `it_admin`
-- ----------------------------
DROP TABLE IF EXISTS `it_admin`;
CREATE TABLE `it_admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(40) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `role_id` int(11) DEFAULT NULL COMMENT '角色id',
  `truename` varchar(40) DEFAULT NULL COMMENT '真名',
  `email` varchar(50) NOT NULL COMMENT '邮箱',
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of it_admin
-- ----------------------------
INSERT INTO `it_admin` VALUES ('1', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '1', '游龙', '123456.gd@163.com', '1459503264');
INSERT INTO `it_admin` VALUES ('24', 'youlong', '202cb962ac59075b964b07152d234b70', '0', '游龙', '123456.gd@163.com', '1505393786');

-- ----------------------------
-- Table structure for `it_attribute`
-- ----------------------------
DROP TABLE IF EXISTS `it_attribute`;
CREATE TABLE `it_attribute` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '商品类型id',
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT '属性名',
  `input_type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '录入方式',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '属性类型',
  `attr_values` text COMMENT '可选值',
  `attr_group` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '所属组',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of it_attribute
-- ----------------------------
INSERT INTO `it_attribute` VALUES ('1', '1', 'I5', '0', '0', null, '0');
INSERT INTO `it_attribute` VALUES ('2', '1', 'I7', '0', '0', null, '0');
INSERT INTO `it_attribute` VALUES ('3', '1', 'I3', '0', '0', null, '0');
INSERT INTO `it_attribute` VALUES ('5', '1', 'CPU', '1', '1', 'I3\r\nI5\r\nI7', '0');

-- ----------------------------
-- Table structure for `it_auth_group`
-- ----------------------------
DROP TABLE IF EXISTS `it_auth_group`;
CREATE TABLE `it_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` char(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of it_auth_group
-- ----------------------------
INSERT INTO `it_auth_group` VALUES ('1', '超级管理员', '1', '1,2,4,5');

-- ----------------------------
-- Table structure for `it_auth_group_access`
-- ----------------------------
DROP TABLE IF EXISTS `it_auth_group_access`;
CREATE TABLE `it_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of it_auth_group_access
-- ----------------------------

-- ----------------------------
-- Table structure for `it_auth_rule`
-- ----------------------------
DROP TABLE IF EXISTS `it_auth_rule`;
CREATE TABLE `it_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `pid` mediumint(8) unsigned NOT NULL,
  `sort` mediumint(1) unsigned NOT NULL DEFAULT '50',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `condition` char(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of it_auth_rule
-- ----------------------------
INSERT INTO `it_auth_rule` VALUES ('1', 'admin', '管理员管理', '1', '0', '50', '1', '');
INSERT INTO `it_auth_rule` VALUES ('2', 'AuthRule', '权限管理', '1', '1', '50', '1', '');
INSERT INTO `it_auth_rule` VALUES ('4', 'AuthRule/index', '列表', '1', '2', '50', '1', '');
INSERT INTO `it_auth_rule` VALUES ('5', 'AuthRule/create', '添加', '1', '2', '50', '1', '');

-- ----------------------------
-- Table structure for `it_category`
-- ----------------------------
DROP TABLE IF EXISTS `it_category`;
CREATE TABLE `it_category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cat_name` varchar(90) NOT NULL DEFAULT '' COMMENT '分类名称',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `cat_desc` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上一级主键',
  `sort_order` tinyint(1) unsigned NOT NULL DEFAULT '50' COMMENT '排序号',
  `is_nav` tinyint(1) NOT NULL DEFAULT '0' COMMENT '导航栏显示',
  `style` varchar(150) DEFAULT NULL COMMENT '个性化样式文件',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='商品分类表';

-- ----------------------------
-- Records of it_category
-- ----------------------------
INSERT INTO `it_category` VALUES ('1', '电脑', '超级电脑', '超级电脑', '0', '50', '1', '', '1');
INSERT INTO `it_category` VALUES ('3', '联想', '联想', '联想', '1', '50', '1', '', '0');
INSERT INTO `it_category` VALUES ('4', 'ThinkPad', 'ThinkPad', 'ThinkPad', '3', '50', '0', '', '1');

-- ----------------------------
-- Table structure for `it_goods`
-- ----------------------------
DROP TABLE IF EXISTS `it_goods`;
CREATE TABLE `it_goods` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cat_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '所属分类id',
  `goods_sn` varchar(60) NOT NULL DEFAULT '',
  `goods_name` varchar(120) NOT NULL DEFAULT '' COMMENT '商品名称',
  `goods_name_style` varchar(60) NOT NULL DEFAULT '+',
  `click_count` int(10) unsigned NOT NULL DEFAULT '0',
  `brand_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `provider_name` varchar(100) NOT NULL DEFAULT '',
  `goods_number` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '库存',
  `goods_weight` decimal(10,3) unsigned NOT NULL DEFAULT '0.000',
  `market_price` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '市场价格',
  `shop_price` decimal(10,0) unsigned NOT NULL DEFAULT '0' COMMENT '本店价格',
  `promote_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `promote_start_date` int(11) unsigned NOT NULL DEFAULT '0',
  `promote_end_date` int(11) unsigned NOT NULL DEFAULT '0',
  `warn_number` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `goods_brief` varchar(255) NOT NULL DEFAULT '',
  `goods_desc` text NOT NULL COMMENT '详细介绍',
  `goods_thumb` varchar(255) NOT NULL DEFAULT '',
  `goods_img` varchar(255) NOT NULL DEFAULT '' COMMENT '高清图',
  `original_img` varchar(255) NOT NULL DEFAULT '',
  `is_real` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `extension_code` varchar(30) NOT NULL DEFAULT '',
  `is_on_sale` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `is_alone_sale` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `is_shipping` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `integral` int(10) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `sort_order` smallint(4) unsigned NOT NULL DEFAULT '100',
  `is_delete` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_best` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_new` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_hot` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_promote` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `bonus_type_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `last_update` int(10) unsigned NOT NULL DEFAULT '0',
  `goods_type` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '商品类型id',
  `seller_note` varchar(255) NOT NULL DEFAULT '',
  `give_integral` int(11) NOT NULL DEFAULT '-1',
  `rank_integral` int(11) NOT NULL DEFAULT '-1',
  `suppliers_id` smallint(5) unsigned DEFAULT NULL,
  `is_check` tinyint(1) unsigned DEFAULT NULL,
  `photo` varchar(2000) NOT NULL COMMENT '相册路径',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='商品基本表';

-- ----------------------------
-- Records of it_goods
-- ----------------------------
INSERT INTO `it_goods` VALUES ('1', '4', '', '测试', '+', '0', '0', '', '123', '0.000', '12', '12', '0.00', '0', '0', '1', '', '123', '<p>fdsfsdfsdfds</p>', '', '20170921/28efffe1609fe799bb2d4a999605932b.jpg', '', '1', '', '1', '1', '0', '0', '1505990363', '100', '0', '1', '0', '0', '0', '0', '0', '1', '', '-1', '-1', null, null, '20170923/883e1eeea42390f0a7f49a17e547ca36.jpg,');
INSERT INTO `it_goods` VALUES ('2', '4', '', '测试2', '+', '0', '0', '', '112', '0.000', '12', '12', '0.00', '0', '0', '1', '', '12e12e', '<p>fsdfsdfdsfdsf</p>', '', '20170923/9c9526e379a7f2f6266ede901acf050b.jpg', '', '1', '', '1', '1', '0', '0', '1506099863', '100', '0', '1', '0', '0', '0', '0', '0', '1', '', '-1', '-1', null, null, '');

-- ----------------------------
-- Table structure for `it_goods_attr`
-- ----------------------------
DROP TABLE IF EXISTS `it_goods_attr`;
CREATE TABLE `it_goods_attr` (
  `goods_attr_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `goods_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'goods表的goods_id',
  `attr_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'attribute表的attr_id',
  `attr_value` text NOT NULL COMMENT '商品属性值',
  `attr_price` decimal(8,0) DEFAULT '0' COMMENT '加价的数目',
  PRIMARY KEY (`goods_attr_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COMMENT='商品属性值';

-- ----------------------------
-- Records of it_goods_attr
-- ----------------------------
INSERT INTO `it_goods_attr` VALUES ('30', '1', '5', '0', '124');
INSERT INTO `it_goods_attr` VALUES ('29', '1', '5', '0', '123');
INSERT INTO `it_goods_attr` VALUES ('28', '1', '3', '12', '0');
INSERT INTO `it_goods_attr` VALUES ('27', '1', '2', '12', '0');
INSERT INTO `it_goods_attr` VALUES ('20', '2', '5', '0', '125');
INSERT INTO `it_goods_attr` VALUES ('19', '2', '5', '0', '124');
INSERT INTO `it_goods_attr` VALUES ('18', '2', '5', '0', '123');
INSERT INTO `it_goods_attr` VALUES ('17', '2', '3', '12', '0');
INSERT INTO `it_goods_attr` VALUES ('16', '2', '2', '12', '0');
INSERT INTO `it_goods_attr` VALUES ('15', '2', '1', '12', '0');
INSERT INTO `it_goods_attr` VALUES ('26', '1', '1', '12', '0');

-- ----------------------------
-- Table structure for `it_goods_type`
-- ----------------------------
DROP TABLE IF EXISTS `it_goods_type`;
CREATE TABLE `it_goods_type` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT '类型名称',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否启用',
  `groups` varchar(255) NOT NULL COMMENT '组名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of it_goods_type
-- ----------------------------
INSERT INTO `it_goods_type` VALUES ('1', '电脑', '1', 'CPU\r\n内存');
INSERT INTO `it_goods_type` VALUES ('3', '测试', '1', '测试1\r\n测试2');
