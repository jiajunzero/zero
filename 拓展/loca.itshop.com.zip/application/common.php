<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
function upload()
{
	$key = key($_FILES);
	// 获取表单上传文件 例如上传了001.jpg
    $file = request()->file($key);
    $data = '';
    // 移动到框架应用根目录/public/uploads/ 目录下
    if($file){
    	$path = './uploads/goods/';
        $info = $file->move($path);
        if($info){
        	//获取文件名
            $data = $info->getSaveName();
            $thumb = config('THUMB');
            //文件后缀
            $ext = $info->getExtension();
            //获取文件名称(带后缀)
            $fileName = $info->getSaveName();
            //去除文件后缀
            $fileName = substr($fileName, 0, -(strlen($ext) + 1) );
            //实例化缩略图类
            $image = \think\Image::open($path . $data);
            //遍历生成缩略图
            foreach ($thumb['spec'] as $v)
            {
                $newName = $fileName . "_{$v}." . $ext;
            	$image->thumb($thumb[$v.'w'],$thumb[$v.'h'],\think\Image::THUMB_FILLED)->save( $path . $newName );
            }
        }
    }
    return $data;
}