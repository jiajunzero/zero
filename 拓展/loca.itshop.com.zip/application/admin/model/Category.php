<?php
namespace app\admin\model;
use think\Model;
class Category extends Model
{
    //验证规则
    public $rule = [
        'cat_name'      => 'require',
    ];
    //提示语
    public $msg = [
            'cat_name.require'      => '分类名称不能为空！',
    ];
}
