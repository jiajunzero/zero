<?php
namespace app\admin\model;
use think\Model;

class Attribute extends Model
{
    //验证规则
    public $rule = [
        'name'      		=> 'require',
        'type_id'       	=> 'egt:1',
    ];
    //提示语
    public $msg = [
            'name.require'      	=> '属性名称不能为空！',
            'type_id.egt'       	=> '请选择所属类型',
    ];
}
