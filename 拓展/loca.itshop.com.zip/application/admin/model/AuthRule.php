<?php
namespace app\admin\model;
use think\Model;

class AuthRule extends Model
{
    //验证规则
    public $rule = [
        'title'      		=> 'require',
        'name'      		=> 'require',
    ];
    //提示语
    public $msg = [
            'title.require'      	=> '权限名称不能为空！',
            'name.require'      	=> '权限规则不能为空！',
    ];
}
