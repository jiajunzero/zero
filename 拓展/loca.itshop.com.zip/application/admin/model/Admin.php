<?php
namespace app\admin\model;
use think\Model;

class Admin extends Model
{
	protected $auto = [];				            //新增与更新需要自动完成的字段
    protected $insert = ['addtime','password'];	    // 新增时需要自动完成的字段
    protected $update = [];                         // 更新时需要自动完成的字段
    //验证规则
    public $rule = [
        'username'      => 'require',
        'password'      => 'require',
        'password2'     => 'require|confirm:password',
        'truename'      => 'require',
        'email'         => 'require|email',
    ];
    //提示语
    public $msg = [
            'username.require'      => '名称不能为空！',
            'password.require'      => '密码不能为空！',
            'password2.require'     => '两次密码不一致！',
            'truename.require'      => '真实姓名不能为空！',
            'email.require'         => '邮箱格式错误',
        ];
    //自动完成时间
    protected function setAddtimeAttr()
    {
        return time();
    }
    //自动完成密码加密
    protected function setPasswordAttr($value)
    {
        return md5($value);
    }

}
