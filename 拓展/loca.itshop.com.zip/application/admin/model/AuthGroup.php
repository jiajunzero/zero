<?php
namespace app\admin\model;
use think\Model;

class AuthGroup extends Model
{
    //验证规则
    public $rule = [
        'title'      		=> 'require',
    ];
    //提示语
    public $msg = [
            'title.require'      	=> '角色名称不能为空！',
    ];


    protected static function init()
    {
        //新增前处理函数
        AuthGroup::event('before_insert', function ($data) {
        	$data['rules'] = implode(',', $data['rules']);
        });

        //更新前处理函数
        AuthGroup::event('before_update', function ($data) {
            $data['rules'] = implode(',', $data['rules']);
        });
    }
}
