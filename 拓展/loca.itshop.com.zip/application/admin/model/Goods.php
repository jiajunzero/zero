<?php
namespace app\admin\model;
use think\Model;
use think\Db;

class Goods extends Model
{
    //验证规则
    public $rule = [
        'goods_name'      => 'require',
    ];
    //提示语
    public $msg = [
            'goods_name.require'      => '属性名称不能为空！',
    ];

    //新增前
    protected static function init()
    {
        //新增前(前钩子程序)
        Goods::event('before_insert', function($data){
            //添加时间
            $data['add_time'] = time();
            //文件上传
            $data['goods_img'] = upload();
        });

        //新增后(后钩子程序)
        Goods::event('after_insert', function($data){
            $arr = array();
            $value = $_POST['attr_value'];
            $price = $_POST['attr_price'];
            foreach ($value as $k => $v)
            {
                if( !$v ) continue;
                if( is_array( $v ) )
                {
                    foreach($v as $kk => $vv)
                    {
                        $arr[] = array(
                            'goods_id'=>    $data['id'],
                            'attr_id'=>     $k,
                            'attr_value'=>  $vv,
                            'attr_price'=>  $price[$k][$kk],
                        );
                    }
                }
                else
                {
                    $arr[] = array(
                        'goods_id'=>    $data['id'],
                        'attr_id'=>     $k,
                        'attr_value'=>  $v,
                        'attr_price'=>  0,
                    );
                }
            }
            //批量新增
            Db::name('goods_attr')->insertAll($arr);
        });

        //更新前(前钩子程序)
        Goods::event('before_update', function($data){
            //判断是否修改图片，如果修改才执行上传函数
            if( request()->file('goods_img') ){
                //文件上传
                $data['goods_img'] = upload();
            }
        });

        //更新后(后钩子程序)
        Goods::event('after_update', function($data){
            $arr = array();
            $value = $_POST['attr_value'];
            $price = $_POST['attr_price'];
            foreach ($value as $k => $v)
            {
                if( !$v ) continue;
                if( is_array( $v ) )
                {
                    foreach($v as $kk => $vv)
                    {
                        $arr[] = array(
                            'goods_id'=>    $data['id'],
                            'attr_id'=>     $k,
                            'attr_value'=>  $vv,
                            'attr_price'=>  $price[$k][$kk],
                        );
                    }
                }
                else
                {
                    $arr[] = array(
                        'goods_id'=>    $data['id'],
                        'attr_id'=>     $k,
                        'attr_value'=>  $v,
                        'attr_price'=>  0,
                    );
                }
            }
            $goodsAttrModel = Db::name('goods_attr');
            //在入库之前先把原来的商品属性值删除
            $goodsAttrModel->where('goods_id', $data['id'])->delete();
            //批量新增
           $goodsAttrModel->insertAll($arr);
        });

        //删除后(后钩子程序)
        Goods::event('after_delete', function($data){
            //删除对应的商品属性
            Db::name('goods_attr')->where('goods_id', $data['id'])->delete();
        });
    }
}
