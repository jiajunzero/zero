<?php
namespace app\admin\model;
use think\Model;

class GoodsType extends Model
{
    //验证规则
    public $rule = [
        'name'      => 'require',
    ];
    //提示语
    public $msg = [
            'name.require'      => '属性名称不能为空！',
    ];
}
