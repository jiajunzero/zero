<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\AuthRule;
use think\Request;

class AuthGroupController extends CommonController
{
    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //获取权限信息
        $authRule = AuthRule::select();
        $authRule = $this->getTrre($authRule);
        //将每个主键都放到一个以上级主键为下标的数组中
        $authTo = array();
        foreach ($authRule as $k => $v)
        {
        	$authTo[ $v['pid'] ][] = $v['id'];
        }

        return view( strtolower( substr(request()->controller(), 0, -10) ) . '/info', ['authRule'=>$authRule, 'authTo'=>$authTo] );
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id, Request $request)
    {
        //拼接模型
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $model = new $model();
        $info = $model->find($id);
        //获取权限信息
        $authRule = AuthRule::select();
        $authRule = $this->getTrre($authRule);
        //将每个主键都放到一个以上级主键为下标的数组中
        $authTo = array();
        foreach ($authRule as $k => $v)
        {
        	$authTo[ $v['pid'] ][] = $v['id'];
        }
        return view( strtolower( $controller ) . '/edit', ['info'=>$info, 'authRule'=>$authRule, 'authTo'=>$authTo] );
    }
}
