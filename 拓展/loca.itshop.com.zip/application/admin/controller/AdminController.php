<?php
namespace app\admin\controller;
use think\Controller;

class AdminController extends CommonController
{

}
