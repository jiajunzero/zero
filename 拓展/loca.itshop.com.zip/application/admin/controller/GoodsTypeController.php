<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\GoodsType;

class GoodsTypeController extends CommonController
{
    //获取类型组数据
    public function getAttr($id = 0)
    {
    	//根据ID获取类型信息
    	$getAttr = GoodsType::field('groups')->find($id);
    	$getAttr = explode(PHP_EOL, $getAttr['groups']);
    	$json = '';
    	foreach ($getAttr as $k => $v)
    	{
    		$json .= "<option value='$k'>$v</option>";
    	}
    	return $json;
    }
}
