<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\Category;
use app\admin\model\GoodsType;
use think\Request;

class GoodsController extends CommonController
{
    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //获取分类信息
        $category = Category::select();
        $category = $this->getTrre($category);

        //获取所商品属性信息
        $goodsType = GoodsType::field('id,name')->select();

        return view( strtolower( substr(request()->controller(), 0, -10) ) . '/info', ['category'=>$category, 'goodsType'=>$goodsType] );
    }

    /**
     * 显示编辑资源表单页.
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id, Request $request)
    {
        //拼接模型，根据ID获取商品信息
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $model = new $model();
        $info = $model->find($id);

        //获取分类信息
        $category = Category::select();
        $category = $this->getTrre($category);

        //获取所商品属性信息
        $goodsType = GoodsType::field('id,name')->select();
        return view( strtolower( $controller ) . '/edit', ['info'=>$info, 'category'=>$category, 'goodsType'=>$goodsType] );
    }

    //相册
    public function ajax_upload()
    {
        $name = upload();
        return $name;
    }

    public function ajax_index(Request $request)
    {
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $data = ( new $model() )
                ->field('id,goods_img,goods_name,cat_id,market_price,shop_price,goods_number,is_best,is_new,is_hot')
                ->select();
        $datas = array(
            "draw"=> $request->get('draw'),             // ajax请求次数，作为标识符
            "recordsTotal"=> 1,     // 总数量
            "recordsFiltered"=> 1,  // 筛选后的总数量
            "data"=>$data
        );

        return json($datas);
    }
}
