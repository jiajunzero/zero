<?php
namespace app\admin\controller;
use think\Controller;
use think\Request;
use think\Validate;

class CommonController extends Controller
{
	/**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index(Request $request)
    {
        //拼接模型
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $data = ( new $model() )->select();
        return view( strtolower($controller) . '/index',['data'=>$data] );
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
        return view( strtolower( substr(request()->controller(), 0, -10) ) . '/info' );
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //接收参数
        $data = $request->post();

        //拼接模型
        $model = "\app\admin\model\\" . substr($request->controller(), 0, -10);
        $model = new $model($data);
        //验证数据
        $validate = new Validate($model->rule, $model->msg);
        //验证失败并返回错误信息
        if( !$validate->check($data) ) return json(['status'=>2, 'msg'=>$validate->getError()]);    //获取错误信息

        //新增数据
        $insert = $model->allowField(true)->save();
        //新增失败返回错误信息
        if( !$insert )  return json(['status'=>1, 'msg'=>'增加失败！']);
        //新增成功返回成功信息
        return json(['status'=>0, 'msg'=>'增加成功']);
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id, Request $request)
    {
        //拼接模型
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $model = new $model();
        $info = $model->find($id);
        return view( strtolower( $controller ) . '/edit', ['info'=>$info] );
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
    	//当前控制器名称
    	$controller = substr($request->controller(), 0, -10);
        //拼接模型
        $model = "\app\admin\model\\" . $controller;
        $model = new $model();
        $data = $request->post();
        $rule = $model->rule;
        if( 'Admin' == $controller ){
	        if( !$data['password'] )    //如果密码为空，则不修改密码
	        {
	            unset($data['password']);   //删除密码
	            unset($rule['password']);   //不需要验证
	            unset($rule['password2']);  //不需要验证
	        }
    	}
        //验证数据
        $validate = new Validate($rule, $model->msg);
        //验证失败并返回错误信息
        if( !$validate->check($data) ) return json(['status'=>2, 'msg'=>$validate->getError()]);    //获取错误信息

        if( ( $model->allowField(true)->save($data,['id'=>$id]) ) === false ) return json(['status'=>1, 'msg'=>'编辑失败！']);
        //编辑成功返回成功信息
        return json(['status'=>0, 'msg'=>'编辑成功']);
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        //拼接模型
        $model = "\app\admin\model\\" . substr(request()->controller(), 0, -10);
        //删除失败返回值
        if( $model::destroy($id) === false ) return json(['status'=>1, 'msg'=>'删除失败！']);
        //删除成功返回值
        return json(['status'=>0, 'msg'=>'删除成功']);
    }

    //无限级分类
    public function getTrre($data, $id = 0, $pid = 0, $level = 0)
    {
        static $list = [];
        foreach ($data as $k => $v)
        {
            if( $v['pid'] == $pid && $v['id'] != $id )
            {
                $v['level'] = $level;
                $list[$v['id']] = $v;
                unset($data[$k]);
                $this->getTrre($data, $id, $v['id'], $level+1);
            }
        }
        return $list;
    }
}
