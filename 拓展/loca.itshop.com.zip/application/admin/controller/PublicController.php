<?php

namespace app\admin\controller;

use think\Controller;
use think\captcha\Captcha;
use think\Validate;

class PublicController extends Controller
{
    //用户登陆
    public function login()
    {
    	if( request()->isPost() )	//判断请求类是否为post
    	{
    		$this->_login();
    		exit;
    	}
    	return view('public/login');
    }

    //验证用记信息
    protected function _login()
    {
    	//需要验证的字段与验证类型
    	$rule = [
		    'username'  => 'require',
		    'password'  => 'require',
		    'code' 		=> 'require',
		];
		//验证失败提示语
		$msg = [
		    'username.require'	=> '用户名不能为空！',
		    'password.require'	=> '密码不能为空！',
		    'code.require'   	=> '验证码不能为空！',
		];
		//接收参数
		$data = input('post.');
		//验证数据
		$validate   = Validate::make($rule,$msg);
		if( ! $validate->check($data) ) $this->error( $validate->getError() );

		//验证验证码合法性
		$captcha = new Captcha();
    	if( ! $captcha->check($data['code']) )	$this->error('验证码错误！');
    	//验证用户信息合法性
    	$userinfo = db('Admin')->where('username',$data['username'])->find();
    	if( !$userinfo ) $this->error('用户名不存在！');
    	if( $userinfo['password'] != md5($data['password']) ) $this->error('密码错误！');

    	//保存用户信息到session中
    	session('userinfo', $userinfo);

    	$this->success('登陆成功', url('/admin/index'));
    }

    public function code()
    {
    	$captcha = new Captcha();
		$captcha->fontSize = 20;
		$captcha->imageH = 40;
		$captcha->length   = 3;
		$captcha->useNoise = false;
		return $captcha->entry();
    }
}

