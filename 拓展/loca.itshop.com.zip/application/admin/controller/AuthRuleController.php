<?php
namespace app\admin\controller;
use think\Controller;
use think\Request;

class AuthRuleController extends CommonController
{
    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
    	$controller = substr(request()->controller(), 0, -10);
        //拼接模型
        $model = "\app\admin\model\\" . $controller;
        //获取所有权限信息
        $authRule = (new $model())->select();
        $authRule = $this->getTrre( $authRule );
        return view( strtolower( $controller ) . '/info', ['authRule'=>$authRule] );
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id, Request $request)
    {
        //拼接模型
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $model = new $model();
        $info = $model->find($id);
        //获取所有权限信息
        $authRule = $model->select();
        $authRule = $this->getTrre( $authRule, $id );
        return view( strtolower( $controller ) . '/edit', ['info'=>$info, 'authRule'=>$authRule] );
    }
}
