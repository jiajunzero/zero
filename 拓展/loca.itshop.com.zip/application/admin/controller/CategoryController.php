<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\Category;
use think\Request;

class CategoryController extends CommonController
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index(Request $request)
    {
        //拼接模型
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $data = ( new $model() )->select();
        $data = $this->getTrre($data);
        return view( strtolower($controller) . '/index',['data'=>$data] );
    }


    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //获取所有分类信息
        $category = Category::select();
        $category = $this->getTrre($category);
        return view( strtolower( substr(request()->controller(), 0, -10) ) . '/info', ['category'=>$category] );
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id, Request $request)
    {
        //拼接模型
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $model = new $model();
        $info = $model->find($id);
        //获取所有分类信息
        $category = $model->select();
        $category = $this->getTrre($category, $id);

        return view( strtolower( $controller ) . '/edit', ['info'=>$info, 'category'=>$category] );
    }
}
