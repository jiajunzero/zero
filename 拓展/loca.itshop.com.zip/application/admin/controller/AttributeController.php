<?php
namespace app\admin\controller;
use think\Controller;
use think\Request;
use app\admin\model\GoodsType;

class AttributeController extends CommonController
{
    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //获取商品类型信息
        $goodsType = GoodsType::select();
        return view( strtolower( substr(request()->controller(), 0, -10) ) . '/info', ['goodsType'=>$goodsType] );
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id, Request $request)
    {
        //拼接模型
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $model = new $model();
        $info = $model->find($id);
        //获取商品类型信息
        $goodsType = GoodsType::select();
        return view( strtolower( $controller ) . '/edit', ['info'=>$info, 'goodsType'=>$goodsType] );
    }

    /**
     * 获取商品属性组
     * @param  integer $id
     */
    public function getAttr($id = 0, $goods_id = 0, Request $request)
    {
        //拼接模型
        $controller = substr($request->controller(), 0, -10);
        $model = "\app\admin\model\\" . $controller;
        $model = new $model();
        //根据ID获取属性组
        //join('__WORK__ w','a.id = w.artist_id')
        $getAttr = $model->where('a.type_id', $id)
                         ->alias('a')
                         ->join('__GOODS_ATTR__ ga','a.id = ga.attr_id and ga.goods_id='.$goods_id, 'LEFT')
                         ->order('ga.attr_id asc')
                         ->select();

        foreach ($getAttr as $k => $v)
        {
            $getAttr[$k]['attr_values'] = explode(PHP_EOL, $v['attr_values']);
        }
        return view( strtolower( $controller ) . '/getAttr', ['getAttr'=>$getAttr] );
    }

}
