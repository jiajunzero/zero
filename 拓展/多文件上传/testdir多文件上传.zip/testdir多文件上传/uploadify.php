<?php
/*
Uploadify
Copyright (c) 2012 Reactive Apps, Ronnie Garcia
Released under the MIT License <http://www.opensource.org/licenses/mit-license.php> 
*/

// Define a destination
$targetFolder = '/uploads/'; // 保存的路径，不要写错哦

$verifyToken = md5('unique_salt' . $_POST['timestamp']);

if (!empty($_FILES) && $_POST['token'] == $verifyToken) {
	$tempFile = $_FILES['Filedata']['tmp_name'];
	$targetPath = $_SERVER['DOCUMENT_ROOT'] . $targetFolder;
	$targetFile = rtrim($targetPath,'/') . '/' . $_FILES['Filedata']['name'];
	
	// Validate the file type
	$fileTypes = array('jpg','jpeg','gif','png'); // 文件后缀
	$fileParts = pathinfo($_FILES['Filedata']['name']);
	if (in_array($fileParts['extension'],$fileTypes)) {
		//如果失败可以用sleep(5)暂停迁移文件，跟踪$tempFile路径的temp文件是否上传，一般php进程结束，temp文件都会删除
		//sleep(5);
		$isupload = move_uploaded_file($tempFile,$targetFile);
		if($isupload){
			//如果成功
			echo "success in the $targetFile";
		}else{
			//失败
			echo 'fail';
		}
	} else {
		echo 'Invalid file type.';
	}
}
?>