<?php
/**
 * @Author: YouLong
 * @Date:   2017-01-08 00:37:43
 * @Last Modified by:   YouLong
 * @Last Modified time: 2017-01-19 17:35:42
 */
namespace app\Youlong\controller;
use think\Controller;
use think\Request;

class Login extends Controller
{
	public function login()
	{
		if(Request::instance()->isPOST())
		{
			if(!captcha_check(input('post.code')))
			{
				$this->error('验证码错误');
			}
			$adminModel = model('AdminModel');
			$data = $adminModel->getOne();

			if($data['status'] == 1 || $data['status'] == 2)
			{
				$this->error($data['msg']);
			}
			if($data['status'] == 0)
			{
				$this->success($data['msg'], url('Index/index'));
			}
			exit;
		}
		return view();
	}

	public function outlogin()
	{
		session('USER','');
		session_destroy();
		$this->success('注销成功', url('Login/login'));
		exit;
	}
}