<?php
/**
 * @Author: YouLong
 * @Date:   2017-01-07 22:47:52
 * @Last Modified by:   YouLong
 * @Last Modified time: 2017-01-10 10:55:23
 */
namespace app\Youlong\controller;
use think\Controller;

class Common extends controller
{
	public function _initialize()
	{
		if(!session('USER.id') || !session('USER.username'))
		{
			$this->success('登陆超时，请重新登陆', url('Login/login'));
		}
	}
}