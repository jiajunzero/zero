<?php
/**
 * @Author: YouLong
 * @Date:   2017-01-14 17:15:00
 * @Last Modified by:   YouLong
 * @Last Modified time: 2017-01-14 17:44:23
 */
namespace app\Youlong\model;
use think\Model;
use think\Db;

class LinksModel extends Model
{
	public function getALl()
	{
		return Db::name('Links')->select();
	}

	public function getOne($id = 0)
	{
		return Db::name('Links')->find($id);
	}

	public function insert()
	{
		return Db::name('Links')->insert(input('post.'));
	}

	public function updates()
	{
		return Db::name('Links')->update(input('post.'));
	}

	public function del($id = 0)
	{
		return Db::name('Links')->delete($id);
	}
}