<?php
/**
 * @Author: YouLong
 * @Date:   2017-01-19 19:41:16
 * @Last Modified by:   YouLong
 * @Last Modified time: 2017-01-19 19:50:58
 */
namespace app\index\controller;

class About extends Common
{
	public function show($nc_id = 0)
	{
		$newsModel = model('NewsModel');
		$this->assign('data', $newsModel->getOne($nc_id) );
		return view('About/show');
	}
}