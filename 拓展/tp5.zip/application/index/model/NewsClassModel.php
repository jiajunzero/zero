<?php
/**
 * @Author: YouLong
 * @Date:   2017-01-19 19:06:41
 * @Last Modified by:   YouLong
 * @Last Modified time: 2017-01-19 19:07:47
 */
namespace app\index\model;
use think\Model;
use think\Db;

class NewsClassModel extends Model
{
	public function getAll()
	{
		return Db::name('NewsClass')->select();
	}
}