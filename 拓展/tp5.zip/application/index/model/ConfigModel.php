<?php
/**
 * @Author: YouLong
 * @Date:   2017-01-13 20:07:40
 * @Last Modified by:   YouLong
 * @Last Modified time: 2017-01-13 20:09:10
 */
namespace app\index\Model;
use think\Model;
use think\Db;

class ConfigModel extends Model
{
	public function getOne()
	{
		return Db::name('config')->find();
	}
}