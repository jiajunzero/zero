<?php
/**
 * @Author: YouLong
 * @Date:   2017-01-13 19:34:18
 * @Last Modified by:   YouLong
 * @Last Modified time: 2017-01-13 19:36:29
 */
namespace app\index\model;
use think\Model;
use think\Db;

class CategoryModel extends Model
{
	public function getAll()
	{
		return Db::name('category')->select();
	}
}
