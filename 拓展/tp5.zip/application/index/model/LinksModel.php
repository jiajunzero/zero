<?php
/**
 * @Author: YouLong
 * @Date:   2017-01-19 19:19:47
 * @Last Modified by:   YouLong
 * @Last Modified time: 2017-01-19 19:20:50
 */
namespace app\index\model;
use think\Model;
use think\Db;

class LinksModel extends Model
{
	public function getAll()
	{
		return Db::name('Links')->select();
	}
}