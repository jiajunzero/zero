<?php
/**
 * @Author: YouLong
 * @Date:   2017-01-19 19:49:41
 * @Last Modified by:   YouLong
 * @Last Modified time: 2017-01-19 19:52:55
 */
namespace app\index\model;
use think\Model;
use think\Db;

class NewsModel extends Model
{
	public function getOne($nc_id = 0)
	{
		return Db::name('News')->where('nc_id',$nc_id)->find();
	}
}