/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50547
Source Host           : 127.0.0.1:3306
Source Database       : tp5blog

Target Server Type    : MYSQL
Target Server Version : 50547
File Encoding         : 65001

Date: 2017-02-09 14:24:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `youlong_admin`
-- ----------------------------
DROP TABLE IF EXISTS `youlong_admin`;
CREATE TABLE `youlong_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `password` char(32) DEFAULT NULL COMMENT '密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of youlong_admin
-- ----------------------------
INSERT INTO `youlong_admin` VALUES ('1', 'admin', 'e10adc3949ba59abbe56e057f20f883e');

-- ----------------------------
-- Table structure for `youlong_article`
-- ----------------------------
DROP TABLE IF EXISTS `youlong_article`;
CREATE TABLE `youlong_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `img` varchar(255) DEFAULT NULL COMMENT '缩略图',
  `cid` int(11) DEFAULT NULL COMMENT '所属分类',
  `ishome` tinyint(4) DEFAULT NULL COMMENT '首页',
  `isvouch` tinyint(4) DEFAULT NULL COMMENT '推荐',
  `istop` tinyint(4) DEFAULT NULL COMMENT '置顶',
  `note` varchar(255) DEFAULT NULL COMMENT '描述',
  `s_title` varchar(50) DEFAULT NULL COMMENT '关键字标题',
  `keywords` varchar(200) DEFAULT NULL COMMENT '内容关键字',
  `s_desc` varchar(200) DEFAULT NULL COMMENT '关键字描述',
  `sort` int(11) DEFAULT '50' COMMENT '排序',
  `addtime` int(11) DEFAULT NULL COMMENT '发布时间',
  `authour` varchar(50) DEFAULT NULL COMMENT '作者',
  `views` int(10) unsigned DEFAULT NULL COMMENT '点击次数',
  `content` text COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of youlong_article
-- ----------------------------
INSERT INTO `youlong_article` VALUES ('1', '图标设计流程及小技巧', '20170110\\9125dcd8310e2103c0c78cdd613522aa.png', '2', '1', '1', '1', '测试', '测试', '测试', '测试', '3', '2017', '游龙', '500', '<p>图形创建 vs 图形样式 我认为，对矢量路径的创建和图形样式的设定作出正确的区分是十分重要的，因为它们需要通过两种截然不同的设计软...</p>');
INSERT INTO `youlong_article` VALUES ('2', '永恒经典-18个黑白灰配色的网', '20170110\\f51392dff5a84a88cecc743665147a21.png', '2', '1', '1', '1', '黑与白的搭配可以体现出简约、现代的感觉，在建筑、家居、艺术设计中很常用，然而在网页设计上也是可以使用黑白搭配，对于这类型的...', '测试2', '测试2', '测试2测试2测试2测试2', '2', '2017', '游龙', '500', '<p>黑与白的搭配可以体现出简约、现代的感觉，在建筑、家居、艺术设计中很常用，然而在网页设计上也是可以使用黑白搭配，对于这类型的...</p>');
INSERT INTO `youlong_article` VALUES ('3', '学学这些爱不释手的加载动效', '20170111\\008ee990b75ef402d3c49fe707c2d04d.png', '3', '1', '1', '1', '我们现在越来越注重细节，小到加载动画，大到界面配色。这些都会成为用户吐槽的地方，一个不小心，你设计的东西让用户反感了，他们...', 'fdsfds', 'fsdf', 'fsdfs', '1', '1970', '游龙', '43', '<p>我们现在越来越注重细节，小到加载动画，大到界面配色。这些都会成为用户吐槽的地方，一个不小心，你设计的东西让用户反感了，他们...</p>');
INSERT INTO `youlong_article` VALUES ('5', '设计师也要学物理学', '20170113\\73075d9385eb4b6f1ef9abf42ba43228.png', '7', '1', '1', null, '物理没学好的射鸡师们别跑！请不要一看见物理学三个字就溜掉了，小编今天带来的文章，并不深入物理定律的本身，只讲述运动曲线的运...', '关键字标题', '内容关键字', '关键字描述', '50', '1484308900', '游龙', '50', '<p>物理没学好的射鸡师们别跑！请不要一看见物理学三个字就溜掉了，小编今天带来的文章，并不深入物理定律的本身，只讲述运动曲线的运...</p>');
INSERT INTO `youlong_article` VALUES ('6', '这10个错误让你的网页显得不专', '20170113\\5a188b717077f0f38124b4bd83d009d9.png', '4', '1', '1', '1', '做一个自己的网站可能对于资金紧张的创业者来说是个很好的idea。当你的初创公司略有起色的时候，你找到一个设计师就好了，之后可以考...', '键字标题', '内容关键', '键字描', '50', '1484308918', '游龙', '50', '<p>做一个自己的网站可能对于资金紧张的创业者来说是个很好的idea。当你的初创公司略有起色的时候，你找到一个设计师就好了，之后可以考...</p>');
INSERT INTO `youlong_article` VALUES ('7', '教你绘制扁平风火箭图标', '20170113\\2156a7d348425a787ef132924df57063.png', '5', '1', '1', '0', '绘制火箭图标 这些调色板上的颜色是我们将要用到的颜色，我选择了一些不那么鲜艳的颜色，这能和扁平化的图标很好地结合，你可以将这...', '键字标题', '容关键', '关键字描', '50', '2017', '游龙', '50', '<p>绘制火箭图标 这些调色板上的颜色是我们将要用到的颜色，我选择了一些不那么鲜艳的颜色，这能和扁平化的图标很好地结合，你可以将这...</p>');
INSERT INTO `youlong_article` VALUES ('8', '20个等分两栏式的网站设计欣赏', '20170113\\8a653bd6cd49b74096e692e664f1c277.png', '8', '1', '1', '0', '借助栅格系统所提供的结构，网页页面在将内容组织得井井有条的同时，还可以兼顾到漂亮的布局和响应式的变化。这种情况在各类新闻、博客和网络杂志类的网站中并不鲜见。 不过这...', '关键字标题', '内容关键字', '关键字描', '50', '2017', '游龙', '50', '<p>借助栅格系统所提供的结构，网页页面在将内容组织得井井有条的同时，还可以兼顾到漂亮的布局和响应式的变化。这种情况在各类新闻、博客和网络杂志类的网站中并不鲜见。 不过这...</p>');
INSERT INTO `youlong_article` VALUES ('9', '学学这些爱不释手的加载动效设计', '20170113\\f574066eecf7e65eeb7622052841b15f.jpg', '7', '1', '1', '0', '我们现在越来越注重细节，小到加载动画，大到界面配色。这些都会成为用户吐槽的地方，一个不小心，你设计的东西让用户反感了，他们说不定就要和你的产品说拜拜了。所以今天我...', '关键字标题', '内容关键字', '关键字描述：', '50', '2017', '游龙', '50', '<p>我们现在越来越注重细节，小到加载动画，大到界面配色。这些都会成为用户吐槽的地方，一个不小心，你设计的东西让用户反感了，他们说不定就要和你的产品说拜拜了。所以今天我...</p>');
INSERT INTO `youlong_article` VALUES ('10', '永恒经典-18个黑白灰配色的网页欣赏', '20170113\\e2db9b508a1a4b62ecdf410df4833924.png', '2', '1', null, null, '黑与白的搭配可以体现出简约、现代的感觉，在建筑、家居、艺术设计中很常用，然而在网页设计上也是可以使用黑白搭配，对于这类型的黑白配色主题，往往会比丰富多彩的网页更有...', '键字标题', '关键字', '关键字描述', '50', '1484308881', '游龙', '50', '<p>黑与白的搭配可以体现出简约、现代的感觉，在建筑、家居、艺术设计中很常用，然而在网页设计上也是可以使用黑白搭配，对于这类型的黑白配色主题，往往会比丰富多彩的网页更有...</p>');
INSERT INTO `youlong_article` VALUES ('11', '“大字体”秀网站欣赏', '20170113\\6db160953eb5b0ef22ce1856f657feb7.png', '2', '1', null, null, 'Prime Fire Typing One Mighty Roar Curts Special Recipe...', '关键字标', '容关键字', '关键字描述', '50', '1484308861', '游龙', '50', '<p>Prime Fire Typing One Mighty Roar Curts Special Recipe...</p>');
INSERT INTO `youlong_article` VALUES ('12', '登录界面易用与安全哪个更重要？', '20170113\\c6cde5cf62e9bcd36cabfe961e27f60b.png', '4', '1', null, null, '对于GoSquared 的每一个设计细节，我们都非常之上心。最近登陆界面改版，新加入的双重认证机制使得用户账户更加安全，与此同时，我们也借此机会逐步提升用户登陆的体验。 提升登...', '键字标题', '内容关键字', '键字描', '50', '1484308885', '游龙', '50', '<p>对于GoSquared 的每一个设计细节，我们都非常之上心。最近登陆界面改版，新加入的双重认证机制使得用户账户更加安全，与此同时，我们也借此机会逐步提升用户登陆的体验。 提升登...</p>');
INSERT INTO `youlong_article` VALUES ('13', '数据界面如何设计？', '20170113\\d073fc443c96cd45562cd0900df42261.png', '4', '1', null, null, '仪表板、大数据、数据可视化、数据分析越来越多人和企业，开始运用他们的数据来做一些有趣的事情。在我的职业生涯中，有幸参与一大批数据为重的界面设计，我要在此分享一些观...', '关键字标题', '容关键字', '关键字描述', '50', '1484308919', '游龙', '50', '<p>仪表板、大数据、数据可视化、数据分析越来越多人和企业，开始运用他们的数据来做一些有趣的事情。在我的职业生涯中，有幸参与一大批数据为重的界面设计，我要在此分享一些观...</p>');
INSERT INTO `youlong_article` VALUES ('14', '图标设计流程及小技巧', '', '7', '1', null, null, '图形创建 vs 图形样式 我认为，对矢量路径的创建和图形样式的设定作出正确的区分是十分重要的，因为它们需要通过两种截然不同的设计软件来实现Photoshop 和 Illustrator。 Photoshop 的渲...', '关键字标题', '内容关键字', '关键字描述', '50', '1484308890', '游龙', '50', '<p>图形创建 vs 图形样式 我认为，对矢量路径的创建和图形样式的设定作出正确的区分是十分重要的，因为它们需要通过两种截然不同的设计软件来实现Photoshop 和 Illustrator。 Photoshop 的渲...</p>');
INSERT INTO `youlong_article` VALUES ('15', '20个响应式网页设计中的“神话”误区', '20170113\\12f729b5060ffef80c2390778da6ccf0.png', '2', '1', null, null, '虽然很多人都在谈论响应式网页，但并不是每个人都知道他们在说什么。很多时候你看到网上的一些信息也在挑战你对响应式的理解。 有时候一些小报告给你建设性的建议，并帮助你的...', '键字', '内容关键', '关键字描述', '50', '1484308860', '游龙', '50', '<p>虽然很多人都在谈论响应式网页，但并不是每个人都知道他们在说什么。很多时候你看到网上的一些信息也在挑战你对响应式的理解。 有时候一些小报告给你建设性的建议，并帮助你的...</p>');
INSERT INTO `youlong_article` VALUES ('16', '设计师也要学物理学', '20170113\\63dfaf484c30314a455753e3b093470f.png', '8', '1', null, null, '物理没学好的射鸡师们别跑！请不要一看见物理学三个字就溜掉了，小编今天带来的文章，并不深入物理定律的本身，只讲述运动曲线的运用，曾经上课睡觉的同学也不必担心！我们会...', '关键字标', '内容关键', '关键字描', '50', '1484308900', '游龙', '50', '<p>物理没学好的射鸡师们别跑！请不要一看见物理学三个字就溜掉了，小编今天带来的文章，并不深入物理定律的本身，只讲述运动曲线的运用，曾经上课睡觉的同学也不必担心！我们会...</p>');
INSERT INTO `youlong_article` VALUES ('17', '换个姿势做设计！移动端的时代要如何重塑网页', '20170113\\db3816db56ce77a4c20938b29c753d89.png', '8', '1', null, null, '随着时代和技术的发展， 网页设计 的流程正悄无声息地发生着巨大的变化。精准具体的设计交付列表不再是 网页设计 的唯一标准，静态页面设计在整个设计流程中所占的比重也逐步降...', '关键字标题', '内容关键字', '关键字描', '50', '1484308874', '游龙', '50', '<p>随着时代和技术的发展， 网页设计 的流程正悄无声息地发生着巨大的变化。精准具体的设计交付列表不再是 网页设计 的唯一标准，静态页面设计在整个设计流程中所占的比重也逐步降...</p>');

-- ----------------------------
-- Table structure for `youlong_category`
-- ----------------------------
DROP TABLE IF EXISTS `youlong_category`;
CREATE TABLE `youlong_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL COMMENT '分类名称',
  `title` varchar(255) DEFAULT NULL COMMENT '关键字标题',
  `keywords` varchar(255) DEFAULT NULL COMMENT '分类关键字',
  `description` varchar(255) DEFAULT NULL COMMENT '关键字描述',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `pid` int(11) DEFAULT NULL COMMENT '父级id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of youlong_category
-- ----------------------------
INSERT INTO `youlong_category` VALUES ('1', '教程', '教程', '教程', '教程', '50', '0');
INSERT INTO `youlong_category` VALUES ('2', '网页设计', '网页设计', '网页设计', '网页设计', '50', '1');
INSERT INTO `youlong_category` VALUES ('3', 'APP设计', 'APP设计', 'APP设计', 'APP设计', '50', '1');
INSERT INTO `youlong_category` VALUES ('4', '色彩搭配', '色彩搭配', '色彩搭配', '色彩搭配', '50', '1');
INSERT INTO `youlong_category` VALUES ('5', 'PS教程', 'PS教程', 'PS教程', 'PS教程', '50', '1');
INSERT INTO `youlong_category` VALUES ('6', '经验', '经验', '经验', '经验', '50', '0');
INSERT INTO `youlong_category` VALUES ('7', '设计理论', '设计理论', '设计理论', '设计理论', '50', '6');
INSERT INTO `youlong_category` VALUES ('8', '经验分享', '经验分享', '经验分享', '经验分享', '50', '6');

-- ----------------------------
-- Table structure for `youlong_config`
-- ----------------------------
DROP TABLE IF EXISTS `youlong_config`;
CREATE TABLE `youlong_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stitle` varchar(50) DEFAULT NULL COMMENT '网站标题',
  `logo` varchar(200) DEFAULT NULL COMMENT '网站logo',
  `surl` varchar(255) DEFAULT NULL COMMENT '网站域名',
  `skeywords` varchar(255) DEFAULT NULL COMMENT '网站关键字',
  `sdescription` varchar(255) DEFAULT NULL COMMENT '网站描述',
  `scopyright` varchar(255) DEFAULT NULL COMMENT '底部信息',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of youlong_config
-- ----------------------------
INSERT INTO `youlong_config` VALUES ('1', '越甜心', '20170113\\6145a8b9a83b30f941c4c10222657281.png', 'http://www.ishopb.com', '越甜心 越甜心 越甜心 越甜心 越甜心', '越甜心 越甜心 越甜心 越甜心 越甜心', '<a href=\"http://www.miitbeian.gov.cn/\" target=\"_blank\">粤ICP123456</a> | Copyright © 2015-2017 版权所有 技术支持：<a href=\"#\" target=\"_blank\">越甜心网络</a>');

-- ----------------------------
-- Table structure for `youlong_links`
-- ----------------------------
DROP TABLE IF EXISTS `youlong_links`;
CREATE TABLE `youlong_links` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `url` varchar(255) DEFAULT NULL COMMENT 'url',
  `thumb` varchar(200) DEFAULT NULL COMMENT 'logo',
  `note` varchar(255) DEFAULT NULL COMMENT '描述',
  `sort` int(11) DEFAULT '50' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of youlong_links
-- ----------------------------
INSERT INTO `youlong_links` VALUES ('1', '测试', 'http://www.youlongit.com', '20170114\\302d797a2e529f35a710b0d0c72a8f3e.png', 'fsfds', '0');

-- ----------------------------
-- Table structure for `youlong_news`
-- ----------------------------
DROP TABLE IF EXISTS `youlong_news`;
CREATE TABLE `youlong_news` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(200) DEFAULT NULL COMMENT '标题',
  `nc_id` smallint(6) DEFAULT NULL COMMENT '所属分类',
  `thumb` varchar(255) DEFAULT NULL COMMENT '缩略图',
  `posttime` int(11) DEFAULT NULL COMMENT '发表时间',
  `views` int(11) DEFAULT NULL COMMENT '点击量',
  `summary` varchar(255) DEFAULT NULL COMMENT '摘要',
  `content` text COMMENT '文章内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of youlong_news
-- ----------------------------
INSERT INTO `youlong_news` VALUES ('2', '做一个自己的网站可能对于资金紧张的创业者来说是个很好的idea。当你的初创公司略有起色的时候，你找到一个设计师就好了，之后可以考...', '5', '20170119\\0a371a35d2e1dfe8973e693669ffb585.jpg', '1484823682', '50', '做一个自己的网站可能对于资金紧张的创业者来说是个很好的idea。当你的初创公司略有起色的时候，你找到一个设计师就好了，之后可以考...', '<p><span style=\"color: rgb(85, 85, 85); font-family: &quot;Microsoft Yahei&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255);\">做一个自己的网站可能对于资金紧张的创业者来说是个很好的idea。当你的初创公司略有起色的时候，你找到一个设计师就好了，之后可以考...</span></p>');

-- ----------------------------
-- Table structure for `youlong_news_class`
-- ----------------------------
DROP TABLE IF EXISTS `youlong_news_class`;
CREATE TABLE `youlong_news_class` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `news_name` varchar(60) DEFAULT NULL COMMENT '内容分类名称',
  `pid` smallint(5) DEFAULT NULL COMMENT '上级分类id',
  `show_in_nav` tinyint(3) unsigned DEFAULT '1' COMMENT '页脚栏显示',
  `sort_order` smallint(5) unsigned DEFAULT '50' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='内容分类表';

-- ----------------------------
-- Records of youlong_news_class
-- ----------------------------
INSERT INTO `youlong_news_class` VALUES ('1', '运营服务', '0', '0', '50');
INSERT INTO `youlong_news_class` VALUES ('2', '帮助中心', '0', '1', '50');
INSERT INTO `youlong_news_class` VALUES ('3', '站点活动', '1', '1', '50');
INSERT INTO `youlong_news_class` VALUES ('4', '站点公告', '1', '1', '50');
INSERT INTO `youlong_news_class` VALUES ('5', '关于我们', '2', '1', '50');
INSERT INTO `youlong_news_class` VALUES ('6', '商务合作', '2', '1', '50');
INSERT INTO `youlong_news_class` VALUES ('7', '友情链接', '2', '1', '50');
INSERT INTO `youlong_news_class` VALUES ('8', '免责声明', '2', '1', '50');
