<!--
document.write("<a class=\"style03\" href=\"#\" target=\"_blank\"><strong>广告位</strong>\r\n  <h2>文字广告位</h2>\r\n  <p>这里可以放置文字类广告<br/>\r\n     下载模板请到 www.pyh123.com <br/>\r\n     欢迎加入友生网络交流群：213945216\r\n  </p>\r\n</a>");
-->
