<!--
document.write("<a href=\'#\'><img src=\'/style/img/ad3.jpg\' /></a>");
-->
