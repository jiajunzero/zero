<!--
document.write("<a href=\'#\'><img src=\'/style/img/ad4.jpg\' /></a>");
-->
