<!--
document.write("<a href=\'#\'><img src=\'/style/img/ad5.jpg\' /></a>");
-->
