<!--
document.write("<a href=\"#\" target=\"_blank\"><img src=\"/style/img/ad2.jpg\"  border=\"0\" /></a>");
-->
