<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:77:"D:\phpStudy\WWW\loca.th5.com\public/../application/index\view\About\show.html";i:1484827028;s:80:"D:\phpStudy\WWW\loca.th5.com\public/../application/index\view\Public\header.html";i:1484534752;s:79:"D:\phpStudy\WWW\loca.th5.com\public/../application/index\view\Public\right.html";i:1484534833;s:80:"D:\phpStudy\WWW\loca.th5.com\public/../application/index\view\Public\footer.html";i:1484826991;}*/ ?>
﻿<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=10,IE=9,IE=8,ie=7">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<title><?php echo $configs['stitle']; ?> -- <?php echo $configs['sdescription']; ?></title>
<meta name="description" content="<?php echo $configs['sdescription']; ?>" />
<meta name="keywords" content="<?php echo $configs['skeywords']; ?>" />
<meta name="Author" content="<?php echo $configs['surl']; ?>" />
<link rel='stylesheet' id='open_social_css-css'  href="/static/Index/css/os.css" type='text/css' media='all' />
<link rel="stylesheet" href="/static/Index/css/style.css" media="all">
<link rel="stylesheet" href="/static/Index/css/ScrollPic.css" media="all">
<link href="/static/Index/css/font-awesome.min.css" rel="stylesheet" media="screen">
<!--[if lt IE 9]><script src="/static/Index/js/html5.js"></script><![endif]-->
<script src="/static/Index/js/jquery.js"></script>
<script src="/static/Index/js/jquery.ScrollPic.js"></script>
<script>
    window._deel = {
        maillist: '',
        maillistCode: '',
        commenton: 0,
        roll: [0,0]
    }
</script>
<script type="text/javascript">
    $(function(){

      $('.yiz-slider-2').ScrollPic({
            Time: '3000',
            speed: '100%',
            autoscrooll: true
        });
        $(window).scroll(function(){
            $offset = $('.placeholder').offset();//不能用自身的div，不然滚动起来会很卡
            if($(window).scrollTop()>$offset.top){
                $('.header').css({'position':'fixed','top':'0px','left':$offset.left+'px','z-index':'999'});
                $(".container").css({"margin-top":"93px"});
            }else{
                $('.header').removeAttr('style');
                $('.container').removeAttr('style');
            }
        });
    })
</script>
</head>
<body class="home blog">

<div class="placeholder"></div>
<header class="header" style="height: 52px;">
  <div class="navbar">
  <h1 class="logo"><a href="<?php echo url('Index/index'); ?>"><?php echo $configs['stitle']; ?> -- <?php echo $configs['sdescription']; ?> -- <?php echo $configs['surl']; ?></a></h1>
  <ul class="nav">
    <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home"><a href="<?php echo url('Index/index'); ?>">首页</a></li>
    <?php if(is_array($nav) || $nav instanceof \think\Collection): if( count($nav)==0 ) : echo "" ;else: foreach($nav as $key=>$nv): ?>
    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children ">
      <a href="<?php echo url('Article/index',array('id'=>$nv['id'])); ?>"><?php echo $nv['name']; ?></a>
      <ul class="sub-menu">
        <?php if(is_array($nav2[$nv['id']]) || $nav2[$nv['id']] instanceof \think\Collection): if( count($nav2[$nv['id']])==0 ) : echo "" ;else: foreach($nav2[$nv['id']] as $key=>$v2): ?>
          <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
            <a href="<?php echo url('Article/index',array('id'=>$v2['id'])); ?>"><?php echo $v2['name']; ?></a>
          </li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </ul>
    </li>
    <?php endforeach; endif; else: echo "" ;endif; ?>
  </ul>
  <div class="menu pull-right">
   <form  name="formsearch" action="/plus/search.php">
      <input type="hidden" name="kwtype" value="0" />
      <input class="search-input" name="q" id="search-keyword" type="text" placeholder=" 输入你要找的内容" />
      <button type="submit" class="button" title="搜一下！"><i class="fa"></i></button>
    </form>
  </div>
  </div>
</header>
<section class="container">
  <div class="content-wrap">
    <div class="content">
      <header class="article-header">
        <div class="meta">
          <span class="muted"><i class="ico icon-eye-open icon12"></i> <?php echo !empty($data['views'])?$data['views']:0; ?> 浏览</span> </div>
      </header>
      <div class="banner banner-post">
        <div style="margin:10px 0px 10px 0px;"> <a href='#'><img src="/static/Index/picture/ad1.jpg" /></a> </div>
      </div>
      <article class="article-content">
        <blockquote>
          <p><strong>小编：</strong><?php echo $data['title']; ?></p>
        </blockquote>
        <?php echo $data['content']; ?>
        <!--fav-->

        <!--fav end-->

        &nbsp;

      </article>

    </div>
  </div>
 <aside class="sidebar">
  <div class="widget d_banner">
    <div class="d_banner_inner">
      <a href="#"><img src="/static/Index/images/ad2.jpg"></a>
    </div>
  </div>
  <div class="widget d_textbanner">
    <a class="style03" href="#" target="_blank"><strong>广告位</strong>
      <h2>文字广告位</h2>
      <p>这里可以放置文字类广告<br>
         下载模板请到 www.XXXX.com <br>
         欢迎加入友生网络交流群：XXXX
      </p>
    </a>
  </div>
  <div class="widget widget_text">
    <div class="textwidget">
      <a href="#"><img src="/static/Index/images/ad3.jpg"></a>
    </div>
  </div>
  <div class="widget widget_text">
    <div class="textwidget">
      <a href="#"><img src="/static/Index/images/ad4.jpg"></a>
    </div>
  </div>
  <div class="widget d_postlist">
    <h3 class="widget_tit">置顶文章</h3>
    <ul>
      <?php if(is_array($istop) || $istop instanceof \think\Collection): if( count($istop)==0 ) : echo "" ;else: foreach($istop as $key=>$v): ?>
      <li>
        <a href="<?php echo url('index/Article/show',array('id'=>$v['id'])); ?>">
          <span class="thumbnail">
          <img src="/uploads/<?php echo $v['img']; ?>" alt="<?php echo $v['title']; ?>" />
          </span>
          <span class="text"><?php echo $v['title']; ?></span>
          <span class="muted"><?php echo date('Y-m-d',$v['addtime']); ?></span>
          <span class="muted">
            <span class="ds-thread-count" data-replace="1"><?php echo $v['views']; ?>次阅读</span>
          </span>
        </a>
      </li>
      <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
  </div>

  <div class="widget widget_text">
    <div class="textwidget">
      <a href="#"><img src="/static/Index/images/ad5.jpg"></a>
    </div>
  </div>

  <div class="widget d_postlist">
    <h3 class="widget_tit">推荐文章</h3>
    <ul>
      <?php if(is_array($isvouch) || $isvouch instanceof \think\Collection): if( count($isvouch)==0 ) : echo "" ;else: foreach($isvouch as $key=>$v): ?>
      <li>
        <a href="<?php echo url('index/Article/show',array('id'=>$v['id'])); ?>">
          <span class="thumbnail">
          <img src="/uploads/<?php echo $v['img']; ?>" alt="<?php echo $v['title']; ?>" />
          </span>
          <span class="text"><?php echo $v['title']; ?></span>
          <span class="muted"><?php echo date('Y-m-d',$v['addtime']); ?></span>
          <span class="muted">
            <span class="ds-thread-count" data-replace="1"><?php echo $v['views']; ?>次阅读</span>
          </span>
        </a>
      </li>
      <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
  </div>

</aside>
</section>

<footer class="footer">
  <div class="footer-inner">
    <div style="padding:0 20px;overflow:hidden;">
      <div class="copyright pull-left">
      <?php if(is_array($footerTop[2]) || $footerTop[2] instanceof \think\Collection): if( count($footerTop[2])==0 ) : echo "" ;else: foreach($footerTop[2] as $key=>$v): ?>
        <a href="<?php echo url('about/show',array('nc_id'=>$v['id'])); ?>" target="_blank"><?php echo $v['news_name']; ?></a> |
      <?php endforeach; endif; else: echo "" ;endif; ?>
       <?php echo $configs['scopyright']; ?>
      </div>
      <div class="trackcode pull-right">
        <!-- 站长统计 -->
      </div>
    </div>
  </div>
</footer>
</body>
</html>