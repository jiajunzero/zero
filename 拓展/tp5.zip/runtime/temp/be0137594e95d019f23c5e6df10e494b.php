<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\phpStudy\WWW\loca.th5.com\public/../application/youlong\view\News\add.html";i:1484383184;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="/static/Youlong/css/pintuer.css">
<link rel="stylesheet" href="/static/Youlong/css/admin.css">
<link rel="stylesheet" href="/static/vendor/layui//css/layui.css">
<script src="/static/Youlong/js/jquery.js"></script>
<script src="/static/Youlong/js/pintuer.js"></script>
<script src="/static/vendor/layui/layui.js"></script>
<script type="text/javascript" charset="utf-8" src="/static/vendor/ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/static/vendor/ueditor/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="/static/vendor/ueditor/lang/zh-cn/zh-cn.js"></script>
</head>
<body>
<div class="panel admin-panel">
  <div class="panel-head" id="add"><strong><span class="icon-pencil-square-o"></span> <?php echo $tartxt; ?>内容</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="?">
      <div class="form-group">
        <div class="label">
          <label>分类标题：</label>
        </div>
        <div class="field">
          <select id="selCid" name="nc_id" class="input w50">
            <option value="">请选择分类</option>
              <?php if(is_array($nsData) || $nsData instanceof \think\Collection): if( count($nsData)==0 ) : echo "" ;else: foreach($nsData as $key=>$v): ?>
                <option value="<?php echo $v['id']; ?>"><?php echo str_repeat('&nbsp;', $v['level']*4); ?><?php echo $v['news_name']; ?></option>
              <?php endforeach; endif; else: echo "" ;endif; ?>
          </select>
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>标题：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" value="<?php echo !empty($data['title'])?$data['title']:''; ?>" name="title" data-validate="required:请输入标题" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>图片：</label>
        </div>
        <div class="field">
          <input type="text" id="inp" name="thumb" value="<?php echo !empty($data['thumb'])?$data['thumb']:''; ?>" class="input w50" />
          <input type="file" name="file" class="layui-upload-file" style="float:left;">
          <br />
          <br />
          <img id="img" src="<?php echo !empty($data['thumb'])?'/uploads/'.$data['thumb']:'/static/images/thumbview.gif'; ?>" style="width:150px; height:auto;" />
        </div>
      </div>

      <div class="form-group">
        <div class="label">
          <label>发布时间：</label>
        </div>
        <div class="field">
          <script src="/static/Youlong/js/laydate/laydate.js"></script>
          <input type="text" class="laydate-icon input w50" name="posttime" onclick="laydate({istime: true, format: 'YYYY-MM-DD hh:mm:ss'})" value="<?php if(isset($data['posttime'])){ echo date('Y-m-d H:m:s', $data['posttime']); }else{ echo date('Y-m-d H:m:s'); }?>"  data-validate="required:日期不能为空" style="padding:10px!important; height:auto!important;border:1px solid #ddd!important;" />
          <div class="tips"></div>
        </div>
      </div>

      <div class="form-group">
        <div class="label">
          <label>点击次数：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="views" value="<?php echo !empty($data['views'])?$data['views']:50; ?>" data-validate="member:只能为数字"  />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>描述：</label>
        </div>
        <div class="field">
          <textarea class="input" name="summary" style=" height:90px;"><?php echo !empty($data['summary'])?$data['summary']:''; ?></textarea>
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>内容：</label>
        </div>
        <div class="field">
          <script id="editor" name="content" type="text/plain" style="height:450px;"><?php echo !empty($data['content'])?$data['content']:''; ?></script>
          <div class="tips"></div>
        </div>
      </div>


      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <input type="hidden" name="id" value="<?php echo !empty($data['id'])?$data['id']:''; ?>" />
          <button class="button bg-main icon-check-square-o" type="submit"> 提交</button>
        </div>
      </div>
    </form>
  </div>
</div>

</body>
<script>
$("#selCid").val(<?php echo !empty($data['nc_id'])?$data['nc_id']:0; ?>);
  //建议使用工厂方法getEditor创建和引用编辑器实例，如果在某个闭包下引用该编辑器，直接调用UE.getEditor('editor')就能拿到相关的实例
    var ue = UE.getEditor('editor');
  layui.use('upload', function(){
    layui.upload({
      url: '<?php echo url('Article/upload'); ?>' //上传接口
      ,success: function(res){ //上传成功后的回调
        console.log(res)
        $('#inp').val(res);
        $('#img').attr('src', '/uploads/' + res);
      }
    });

    layui.upload({
      url: '/test/upload.json'
      ,elem: '#test' //指定原始元素，默认直接查找class="layui-upload-file"
      ,method: 'get' //上传接口的http类型
      ,success: function(res){
        LAY_demo_upload.src = res.url;
      }
    });
  });
</script>
</html>