<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"D:\phpStudy\WWW\loca.th5.com\public/../application/youlong\view\article\ajaxIndex.html";i:1484114133;}*/ ?>
<?php if(is_array($adata) || $adata instanceof \think\Collection): if( count($adata)==0 ) : echo "" ;else: foreach($adata as $key=>$v): ?>
      <tr>
        <td style="text-align:left; padding-left:20px;">
          <input type="checkbox" name="id[]" value="" /><?php echo $v['id']; ?>
        </td>
        <td>
        <input type="text" name="sort[<?php echo $v['sort']; ?>]" value="<?php echo $v['sort']; ?>" style="width:50px; text-align:center; border:1px solid #ddd; padding:7px 0;" />
        </td>
        <td width="10%">
          <img src="/uploads/<?php echo $v['img']; ?>" alt="" width="70" height="50" />
        </td>
        <td><?php echo $v['title']; ?></td>
        <td>
          <font color="#00CC99">
            <?php echo !empty($v['ishome'])?'首页':''; ?>　<?php echo !empty($v['isvouch'])?'推荐':''; ?>　<?php echo !empty($v['istop'])?'置顶':''; ?>
          </font>
        </td>
        <td><?php echo $cdat[ $v['cid'] ]['name']; ?></td>
        <td><?php echo date('Y-m-d', $v['addtime']); ?></td>
        <td>
          <div class="button-group">
            <a class="button border-main" href="add.html">
              <span class="icon-edit"></span> 修改
            </a>
            <a class="button border-red" href="javascript:void(0)" onclick="return del(1,1,1)">
              <span class="icon-trash-o"></span> 删除
            </a>
          </div>
        </td>
      </tr>
      <?php endforeach; endif; else: echo "" ;endif; ?>