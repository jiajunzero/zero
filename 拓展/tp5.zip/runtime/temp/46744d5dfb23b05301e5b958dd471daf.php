<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\phpStudy\WWW\loca.th5.com\public/../application/youlong\view\Category\add.html";i:1484013266;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="/static/Youlong/css/pintuer.css">
<link rel="stylesheet" href="/static/Youlong/css/admin.css">
<script src="/static/Youlong/js/jquery.js"></script>
<script src="/static/Youlong/js/pintuer.js"></script>
</head>
<body>
<div class="panel admin-panel margin-top">
  <div class="panel-head" id="add"><strong><span class="icon-pencil-square-o"></span>添加内容</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="?">
      <div class="form-group">
        <div class="label">
          <label>上级分类：</label>
        </div>
        <div class="field">
          <select id="pid" name="pid" class="input w50">
            <option value="0">顶级分类</option>
            <?php if(is_array($data) || $data instanceof \think\Collection): if( count($data)==0 ) : echo "" ;else: foreach($data as $key=>$v): ?>
              <option value="<?php echo $v['id']; ?>"><?php echo str_repeat("&nbsp;", $v['level']*4); ?><?php echo $v['name']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
          </select>
          <div class="tips">不选择上级分类默认为一级分类</div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>分类名称：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="name" value="<?php echo !empty($catedata['name'])?$catedata['name']:''; ?>" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>关键字标题：</label>
        </div>
        <div class="field">
          <input type="text" class="input" name="title" value="<?php echo !empty($catedata['title'])?$catedata['title']:''; ?>" />
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>分类关键字：</label>
        </div>
        <div class="field">
          <input type="text" class="input" name="keywords" value="<?php echo !empty($catedata['keywords'])?$catedata['keywords']:''; ?>" />
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>关键字描述：</label>
        </div>
        <div class="field">
          <input type="text" class="input" name="description" value="<?php echo !empty($catedata['description'])?$catedata['description']:''; ?>" />
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>排序：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="sort" value="<?php echo !empty($catedata['sort'])?$catedata['sort']:50; ?>"  data-validate="number:排序必须为数字" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
        <input type="hidden" name="id" value="<?php echo !empty($catedata['id'])?$catedata['id']:''; ?>" />
          <button class="button bg-main icon-check-square-o" type="submit"> 提交</button>
        </div>
      </div>
    </form>
  </div>
  </div>

</body>
<script>
  $('#pid').val(<?php echo !empty($catedata['pid'])?$catedata['pid']:0; ?>);
</script>
</html>