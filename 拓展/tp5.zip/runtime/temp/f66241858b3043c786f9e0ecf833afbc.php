<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"D:\phpStudy\WWW\loca.th5.com\public/../application/youlong\view\NewsClass\add.html";i:1484383890;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="/static/Youlong/css/pintuer.css">
<link rel="stylesheet" href="/static/Youlong/css/admin.css">
<script src="/static/Youlong/js/jquery.js"></script>
<script src="/static/Youlong/js/pintuer.js"></script>
</head>
<body>
<div class="panel admin-panel">
  <div class="panel-head" id="add"><strong><span class="icon-pencil-square-o"></span><?php echo $artext; ?>内容</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="?">
      <div class="form-group">
        <div class="label">
          <label>类型名称：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" value="<?php echo !empty($data['news_name'])?$data['news_name']:''; ?>" name="news_name" data-validate="required:请输入标题" />
          <div class="tips"></div>
        </div>
      </div>

        <div class="form-group">
          <div class="label">
            <label>上级分类：</label>
          </div>
          <div class="field">
            <select name="pid" class="input w50">
              <option value="0">顶级分类</option>
              <?php if(is_array($ncData) || $ncData instanceof \think\Collection): if( count($ncData)==0 ) : echo "" ;else: foreach($ncData as $key=>$v): ?>
                <option value="<?php echo $v['id']; ?>"><?php echo str_repeat("&nbsp;",$v['level']*4); ?><?php echo $v['news_name']; ?></option>
              <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
            <div class="tips"></div>
          </div>
        </div>
        <div class="form-group">
          <div class="label">
            <label>是否显示：</label>
          </div>
          <div class="field" style="padding-top:8px;">
            <input name="show_in_nav" type="radio" value="1" />是　
            <input name="show_in_nav" type="radio" value="0" />否
          </div>
        </div>

      <div class="form-group">
        <div class="label">
          <label>排序：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="sort_order" value="<?php echo !empty($data['sort_order'])?$data['sort_order']:50; ?>"  data-validate="number:排序必须为数字" />
          <div class="tips"></div>
        </div>
      </div>

      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main icon-check-square-o" type="submit"> 提交</button>
        </div>
      </div>
    </form>
  </div>
</div>
</body>
<script>
  $("[name='pid']").val(<?php echo !empty($data['pid'])?$data['pid']:0; ?>);
  $('[name="show_in_nav"]').val([<?php echo isset($data['show_in_nav'])?$data['show_in_nav']:1; ?>]);
</script>
</html>