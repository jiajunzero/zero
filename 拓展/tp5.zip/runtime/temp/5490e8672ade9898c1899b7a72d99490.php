<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"D:\phpStudy\WWW\loca.th5.com\public/../application/youlong\view\Article\index.html";i:1484208222;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="/static/Youlong/css/pintuer.css">
<link rel="stylesheet" href="/static/Youlong/css/admin.css">
<script src="/static/Youlong/js/jquery.js"></script>
<script src="/static/Youlong/js/pintuer.js"></script>
<style>
  .pagination span{color:#333;padding:8px 12px;line-height:18px;display:block;transition:all 1s cubic-bezier(0.175, 0.885, 0.32, 1) 0s;}
  .pagination li{margin-right:5px;}
</style>
</head>
<body>
  <div class="panel admin-panel">
    <div class="panel-head"><strong class="icon-reorder"> 内容列表</strong> <a href="<?php echo url('Article/add'); ?>" style="float:right; display:none;">添加字段</a></div>
    <div class="padding border-bottom">
    <form method="post" action="?" id="listform">
      <ul class="search" style="padding-left:10px;">
        <li> <a class="button border-main icon-plus-square-o" href="add.html"> 添加内容</a> </li>
        <li>搜索：</li>
        <li>首页
          <select name="ishome" class="input" onchange="changesearch(this)" style="width:60px; line-height:17px; display:inline-block">
            <option value="">选择</option>
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
          &nbsp;&nbsp;
          推荐
          <select name="isvouch" class="input" onchange="changesearch(this)"  style="width:60px; line-height:17px;display:inline-block">
            <option value="">选择</option>
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
          &nbsp;&nbsp;
          置顶
          <select name="istop" class="input" onchange="changesearch(this)"  style="width:60px; line-height:17px;display:inline-block">
            <option value="">选择</option>
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
        </li>
          <li>
            <select name="cid" class="input" style="width:200px; line-height:17px;" onchange="changesearch(this)">
              <option value="">请选择分类</option>
              <?php if(is_array($catdata) || $catdata instanceof \think\Collection): if( count($catdata)==0 ) : echo "" ;else: foreach($catdata as $key=>$v): ?>
                <option value="<?php echo $v['id']; ?>"><?php echo str_repeat('&nbsp;', $v['level']*4); ?><?php echo $v['name']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
          </li>
        <li>
          <input type="text" placeholder="请输入搜索关键字" name="title" class="input" style="width:250px; line-height:17px;display:inline-block" />
          <a href="javascript:void(0)" class="button border-main icon-search" onclick="changesearch()" > 搜索</a></li>
      </ul>
      </form>
    </div>
    <table class="table table-hover text-center">
      <tr>
        <th width="100" style="text-align:left; padding-left:20px;">ID</th>
        <th width="10%">排序</th>
        <th>图片</th>
        <th>名称</th>
        <th>属性</th>
        <th>分类名称</th>
        <th width="10%">更新时间</th>
        <th width="310">操作</th>
      </tr>
      <tbody id="tbId">
        <?php if(is_array($adata) || $adata instanceof \think\Collection): if( count($adata)==0 ) : echo "" ;else: foreach($adata as $key=>$v): ?>
        <tr>
          <td style="text-align:left; padding-left:20px;">
            <input type="checkbox" name="id[]" value="<?php echo $v['id']; ?>" /><?php echo $v['id']; ?>
          </td>
          <td>
          <input type="text" name="sort[<?php echo $v['sort']; ?>]" value="<?php echo $v['sort']; ?>" style="width:50px; text-align:center; border:1px solid #ddd; padding:7px 0;" />
          </td>
          <td width="10%">
            <img src="/uploads/<?php echo $v['img']; ?>" alt="" width="70" height="50" />
          </td>
          <td><?php echo $v['title']; ?></td>
          <td>
            <font color="#00CC99">
              <?php echo !empty($v['ishome'])?'首页':''; ?>　<?php echo !empty($v['isvouch'])?'推荐':''; ?>　<?php echo !empty($v['istop'])?'置顶':''; ?>
            </font>
          </td>
          <td><?php echo $cdat[ $v['cid'] ]['name']; ?></td>
          <td><?php echo date('Y-m-d', $v['addtime']); ?></td>
          <td>
            <div class="button-group">
              <a class="button border-main" href="<?php echo url('Article/edit', array('id'=>$v['id'])); ?>">
                <span class="icon-edit"></span> 修改
              </a>
              <a class="button border-red" href="<?php echo url('Article/del', array('id'=>$v['id'])); ?>" onclick="return del(1,1,1)">
                <span class="icon-trash-o"></span> 删除
              </a>
            </div>
          </td>
        </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </tbody>
      <tr>
        <td style="text-align:left; padding:19px 0;padding-left:20px;"><input type="checkbox" id="checkall"/>
          全选 </td>
        <td colspan="7" style="text-align:left;padding-left:20px;"><a href="javascript:void(0)" class="button border-red icon-trash-o" style="padding:5px 15px;" onclick="DelSelect()"> 删除</a> <a href="javascript:void(0)" style="padding:5px 15px; margin:0 10px;" class="button border-blue icon-edit" onclick="sorts()"> 排序</a> 操作：
          <select name="ishome" style="padding:5px 15px; border:1px solid #ddd;" onchange="changeishome(this)">
            <option value="">首页</option>
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
          <select name="isvouch" style="padding:5px 15px; border:1px solid #ddd;" onchange="changeishome(this)">
            <option value="">推荐</option>
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
          <select name="istop" style="padding:5px 15px; border:1px solid #ddd;" onchange="changeishome(this)">
            <option value="">置顶</option>
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
          &nbsp;&nbsp;&nbsp;

          移动到：
          <select name="cid" style="padding:5px 15px; border:1px solid #ddd;" onchange="changeishome(this)">
            <option value="">请选择分类</option>
            <?php if(is_array($catdata) || $catdata instanceof \think\Collection): if( count($catdata)==0 ) : echo "" ;else: foreach($catdata as $key=>$v): ?>
              <option value="<?php echo $v['id']; ?>"><?php echo str_repeat('&nbsp;', $v['level']*4); ?><?php echo $v['name']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
          </select>
          </td>
      </tr>
      <tr>
        <td colspan="8"><?php echo $page; ?></td>
      </tr>
    </table>
  </div>
<script type="text/javascript">

//搜索
function changesearch(){
  $.get("<?php echo url('Article/index'); ?>",$('#listform').serialize(), function(data){
    $('#tbId').html(data);
  });
}

//全选
$("#checkall").click(function(){
  $("input[name='id[]']").each(function(){
	  if (this.checked) {
		  this.checked = false;
	  }
	  else {
		  this.checked = true;
	  }
  });
})

//批量删除
function DelSelect(){
	var Checkbox=false;
	 $("input[name='id[]']").each(function(){
	  if (this.checked==true) {
		Checkbox=true;
	  }
	});
	if (Checkbox){
		var t=confirm("您确认要删除选中的内容吗？");
		if (t==false) return false;
		$("#listform").submit();
	}
	else{
		alert("请选择您要删除的内容!");
		return false;
	}
}

//批量排序
function sorts(){
	var Checkbox=false;
  var $str = '';
	 $("input[name='id[]']").each(function(index,obj){
	  if (this.checked==true) {
      console.log($(obj).val(),$(obj).parent().next().children().val())
      $str += 'id[]='+$(obj).val()+'&sort[]='+$(obj).parent().next().children().val()+'&';
		  Checkbox=true;
	  }
	});
	if (Checkbox){
    $str = $str.substr($str, $str.length-1);
		location.href = "<?php echo url('Article/setSort'); ?>?"+$str;
	}
	else{
		alert("请选择要操作的内容!");
		return false;
	}
}


//批量首页显示 批量推荐 批量置顶 批量移动
function changeishome(o){
	var Checkbox=false;
  var str = '';
	 $("input[name='id[]']").each(function(index,obj){
  	  if (this.checked==true) {
        str += obj.value + ',';
  		  Checkbox=true;
  	  }
	});
	if (Checkbox){
    str = str.substr(0,str.length-1);

    location.href = "<?php echo url('Article/ajaxUpdate'); ?>?id="+str+'&'+$(o).attr('name')+'='+o.value;
	}
	else{
		alert("请选择要操作的内容!");
    $(o).val('');
		return false;
	}
}

</script>
</body>
</html>